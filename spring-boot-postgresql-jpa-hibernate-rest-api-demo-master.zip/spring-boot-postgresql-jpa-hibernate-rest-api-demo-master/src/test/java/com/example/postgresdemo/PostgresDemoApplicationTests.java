package com.example.postgresdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PostgresDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
